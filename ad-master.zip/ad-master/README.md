# ad
Repositorio para el módulo Acceso a Datos del IES Serpis
